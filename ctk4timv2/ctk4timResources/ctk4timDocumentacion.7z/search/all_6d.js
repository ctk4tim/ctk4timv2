var searchData=
[
  ['mathmodule_2ec',['mathModule.c',['../math_module_8c.html',1,'']]],
  ['mathmodule_2eh',['mathModule.h',['../math_module_8h.html',1,'']]],
  ['mathscaleconversion',['mathScaleConversion',['../math_module_8c.html#a41ae79360657a445f5203a9ce6638f5b',1,'mathScaleConversion(double convertValue, double maximumValue):&#160;mathModule.c'],['../math_module_8h.html#a41ae79360657a445f5203a9ce6638f5b',1,'mathScaleConversion(double convertValue, double maximumValue):&#160;mathModule.c']]],
  ['max_5fbuffer_5fchars',['MAX_BUFFER_CHARS',['../led_matrix_module_8h.html#a773d318f5ab766cb5415b7a307a8d02c',1,'ledMatrixModule.h']]],
  ['max_5fbuffer_5foffset',['MAX_BUFFER_OFFSET',['../led_matrix_module_8h.html#a23cd4a9bc95c31b3ef85be4369de3182',1,'ledMatrixModule.h']]],
  ['max_5fcolumns',['MAX_COLUMNS',['../led_matrix_module_8h.html#a2cc6f39fc4594f0e734b2588129fba03',1,'ledMatrixModule.h']]],
  ['max_5fstep_5frgb',['MAX_STEP_RGB',['../rgb_led_module_8c.html#a8625dc87a64c7ec380908710f419540e',1,'rgbLedModule.c']]]
];
