var searchData=
[
  ['enableinterrupts',['enableInterrupts',['../core_module_8c.html#ac4b3f0121a2ac45668528454fbf14f64',1,'enableInterrupts():&#160;coreModule.c'],['../core_module_8h.html#ac4b3f0121a2ac45668528454fbf14f64',1,'enableInterrupts():&#160;coreModule.c']]],
  ['entrylowpowermode0',['entryLowPowerMode0',['../core_module_8c.html#aa0e691b011052bc060b0ede24b0e50b7',1,'entryLowPowerMode0():&#160;coreModule.c'],['../core_module_8h.html#aa0e691b011052bc060b0ede24b0e50b7',1,'entryLowPowerMode0():&#160;coreModule.c']]]
];
