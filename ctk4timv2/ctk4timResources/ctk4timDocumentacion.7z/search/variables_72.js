var searchData=
[
  ['red',['red',['../ctk4tim_8c.html#a3c4cb31423c560b1d5639d20eda0d5fb',1,'ctk4tim.c']]]
];
