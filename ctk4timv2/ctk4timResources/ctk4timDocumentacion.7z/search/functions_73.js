var searchData=
[
  ['spiinit',['spiInit',['../spi_module_8c.html#a51d4f6a2b920dcb4c82e733c27cb1754',1,'spiInit(uchar spiModeInit, uchar csPinPolarityInit):&#160;spiModule.c'],['../spi_module_8h.html#a51d4f6a2b920dcb4c82e733c27cb1754',1,'spiInit(uchar spiModeInit, uchar csPinPolarityInit):&#160;spiModule.c']]],
  ['spireceive',['spiReceive',['../spi_module_8c.html#ae97b7f1c1f78c67183ca654972009aca',1,'spiReceive(uchar *dataPointer, uchar dataLength):&#160;spiModule.c'],['../spi_module_8h.html#ae97b7f1c1f78c67183ca654972009aca',1,'spiReceive(uchar *dataPointer, uchar dataLength):&#160;spiModule.c']]],
  ['spireceivebyte',['spiReceiveByte',['../spi_module_8c.html#a5c8ba4bf475cf9bf8425c16d9c4b6321',1,'spiReceiveByte():&#160;spiModule.c'],['../spi_module_8h.html#a5c8ba4bf475cf9bf8425c16d9c4b6321',1,'spiReceiveByte():&#160;spiModule.c']]],
  ['spisend',['spiSend',['../spi_module_8c.html#a6d5197f41db4224f766f91dc0c2a5cb0',1,'spiSend(uchar *dataPointer, uchar dataLength):&#160;spiModule.c'],['../spi_module_8h.html#a6d5197f41db4224f766f91dc0c2a5cb0',1,'spiSend(uchar *dataPointer, uchar dataLength):&#160;spiModule.c']]],
  ['stopwatchdogtimer',['stopWatchdogTimer',['../core_module_8c.html#a861576c429fafa72d02ea87c1f26dbd5',1,'stopWatchdogTimer():&#160;coreModule.c'],['../core_module_8h.html#a861576c429fafa72d02ea87c1f26dbd5',1,'stopWatchdogTimer():&#160;coreModule.c']]]
];
