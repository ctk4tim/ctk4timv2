var searchData=
[
  ['idx',['IDX',['../core_module_8h.html#a223697fc2f8a4423171d86ced5c8872b',1,'coreModule.h']]]
];
