var searchData=
[
  ['vuchar',['vuchar',['../core_module_8h.html#ab80e518e0204bdd69af46f618742811f',1,'coreModule.h']]]
];
