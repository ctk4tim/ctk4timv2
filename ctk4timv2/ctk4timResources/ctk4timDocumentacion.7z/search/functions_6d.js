var searchData=
[
  ['mathscaleconversion',['mathScaleConversion',['../math_module_8c.html#a41ae79360657a445f5203a9ce6638f5b',1,'mathScaleConversion(double convertValue, double maximumValue):&#160;mathModule.c'],['../math_module_8h.html#a41ae79360657a445f5203a9ce6638f5b',1,'mathScaleConversion(double convertValue, double maximumValue):&#160;mathModule.c']]]
];
