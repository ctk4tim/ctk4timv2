var searchData=
[
  ['keymatrixinit',['keyMatrixInit',['../key_matrix_module_8c.html#a865bb4a52e579fe93c97b961de841e7e',1,'keyMatrixInit():&#160;keyMatrixModule.c'],['../key_matrix_module_8h.html#a865bb4a52e579fe93c97b961de841e7e',1,'keyMatrixInit():&#160;keyMatrixModule.c']]],
  ['keymatrixread',['keyMatrixRead',['../key_matrix_module_8c.html#ae914d84d6b4d8758a809199e540e020b',1,'keyMatrixRead():&#160;keyMatrixModule.c'],['../key_matrix_module_8h.html#ae914d84d6b4d8758a809199e540e020b',1,'keyMatrixRead():&#160;keyMatrixModule.c']]]
];
