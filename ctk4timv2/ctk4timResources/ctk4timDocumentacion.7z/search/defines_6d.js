var searchData=
[
  ['max_5fbuffer_5fchars',['MAX_BUFFER_CHARS',['../led_matrix_module_8h.html#a773d318f5ab766cb5415b7a307a8d02c',1,'ledMatrixModule.h']]],
  ['max_5fbuffer_5foffset',['MAX_BUFFER_OFFSET',['../led_matrix_module_8h.html#a23cd4a9bc95c31b3ef85be4369de3182',1,'ledMatrixModule.h']]],
  ['max_5fcolumns',['MAX_COLUMNS',['../led_matrix_module_8h.html#a2cc6f39fc4594f0e734b2588129fba03',1,'ledMatrixModule.h']]]
];
