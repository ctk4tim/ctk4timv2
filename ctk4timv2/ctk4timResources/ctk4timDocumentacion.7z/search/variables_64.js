var searchData=
[
  ['delayscroll',['delayScroll',['../led_matrix_module_8c.html#a3a9f2b0460a26a6d4a8345bbf4dbe33f',1,'ledMatrixModule.c']]]
];
